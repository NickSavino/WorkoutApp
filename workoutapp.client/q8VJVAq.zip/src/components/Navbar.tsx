import React from "react";
import { Link } from "react-router-dom";
import { useAuth } from "../context/AuthContext";

const Navbar: React.FC = () => {
    const { user, logout } = useAuth();

    return (
        <nav className="bg-midnightBlue text-white py-4 px-6 flex justify-between items-center shadow-md">
            <div className="flex items-center space-x-4">
                <h1 className="text-xl font-bold tracking-wide">Jym</h1>
                {user && (
                    <>
                        <Link to="/home" className="hover:text-gray-300 transition">
                            Home
                        </Link>
                        <Link to="/exercises" className="hover:text-gray-300 transition">
                            Exercises
                        </Link>
                    </>
                )}
            </div>
            <div>
                {user ? (
                    <button 
                        onClick={logout} 
                        className="bg-red-500 hover:bg-red-700 text-white px-4 py-2 rounded-md transition"
                    >
                        Logout
                    </button>
                ) : (
                    <Link 
                        to="/login" 
                        className="bg-blue-500 hover:bg-blue-700 text-white px-4 py-2 rounded-md transition"
                    >
                        Login
                    </Link>
                )}
            </div>
        </nav>
    );
};

export default Navbar;
